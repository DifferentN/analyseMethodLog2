package Basic;


import java.util.ArrayList;

import java.util.ArrayList;
//
public class test3 {
}
//
////public class MainFrame extends Frame {
////    public SubFrame sf;
////}
////public class SubFrame{
////    private static SubFrame sf=null;
////    private SubFrame(){}
////    public static synchronized SubFrame getSubFrame(){
////        if(sf==null){
////            sf=new SubFrame();
////        }
////        return sf;
////    }
////}
////
////public abstract class File{
////    public abstract void browse();
////}
////public class Text extends File{
////    @Override
////    public void browse(){};
////}
////public class Picture extends File{
////    @Override
////    public void browse(){};
////}
////public class Folder extends File{
////    private ArrayList<File> files;
////    public Folder(){
////        files=new ArrayList<>();
////    }
////    public void add(File file){
////        if(file!=null)
////            files.add(file);
////    }
////    public void remove(File file){
////        if(file!=null)
////            files.remove(file);
////    }
////    public File getFile(int index){
////        return files.get(index);
////    }
////    @Override
////    public void browse(){
////        int len=files.size();
////        for(int i=0;i<len;i++){
////            File file=files.get(i);
////            file.browse();
////        }
////
////    };
////}
////
////public class Client{
////    private Robot robot=null;
////    public Client(){}
////    public Client(Robot robot){
////        this.robot=robot;
////    }
////}
////public interface Robot{
////    public void work();
////    public void run();
////    public void fly();
////}
////
////public class RobotAdapter implements Robot{
////    private Bird bird;
////    private Dog dog;
////    public void work(){}
////    public void run(){
////        dog.runInDog();
////    }
////    public void fly(){
////        bird.flyInBird();
////    }
////}
////public class Bird{
////    public void flyInBird(){}
////}
////public class Dog{
////    public void runInDog(){}
////}
////
////public class Client{
////    private PermissionProxy pp=null;
////    public Client(){}
////    public Client(PermissionProxy pp){
////        this.pp=pp;
////    }
////}
////public interface Permission {
////    public void readNote();
////    public void postNote();
////    public void modifyUserInfo();
////    public void setLevel(int level);
////}
////public class RealPermission implements Permission {
////    public void readNote(){}
////    public void postNote(){}
////    public void modifyUserInfo(){}
////    public void setLevel(int level){}
////}
////public class PermissionProxy implements Permission {
////    RealPermission realPermission=new RealPermission();
////    int level;//游客为0，注册为1；
////    public void readNote(){
////        realPermission.readNote();
////    }
////    public void postNote(){
////        if (level==1)
////            realPermission.postNote();
////    }
////    public void modifyUserInfo(){
////        if(level==1)
////            realPermission.modifyUserInfo();
////    }
////    public void setLevel(int level){
////        this.level=level;
////    }
////}
////
//
//public class EncryptionFacade {
//    private ReadFile readFile;
//    private Encrypt encrypt;
//    private WriteFile writeFile;
//
//    public EncryptionFacade() {
//        readFile = new ReadFile();
//        encrypt = new Encrypt();
//        writeFile = new WriteFile();
//    }
//
//    public String readFile() {
//        return readFile.read();
//    }
//
//    public void encryptFile() {
//        encrypt.encrypt();
//    }
//
//    public void writeFile() {
//        writeFile.write();
//    }
//
//}
//
//public class ReadFile {
//    public String read() {
//        String s = null;
//        return s;
//    }
//}
//
//public class Encrypt {
//    public void encrypt() {
//    }
//}
//
//public class WriteFile {
//    public void write() {
//    }
//}
//
//
//public abstract class AbstractCommand {
//    public abstract void execute();
//}
//
//public class OpenCommand extends AbstractCommand {
//    private BoardScreen boardscreen;
//
//    public OpenCommand(BoardScreen boardscreen) {
//        this.boardscreen = boardscreen;
//    }
//    @Override
//    public void execute() {
//        boardscreen.open();
//    }
//}
//
//public class CreateCommand extends AbstractCommand {
//    private BoardScreen boardscreen;
//
//    public CreateCommand(BoardScreen boardscreen) {
//        this.boardscreen = boardscreen;
//    }
//
//    @Override
//    public void execute() {
//        boardscreen.create();
//    }
//}
//
//public class EditCommand extends AbstractCommand {
//    private BoardScreen boardscreen;
//
//    public EditCommand(BoardScreen boardscreen) {
//        this.boardscreen = boardscreen;
//    }
//
//    @Override
//    public void execute() {
//        boardscreen.edit();
//    }
//}
//
//public class BoardScreen {
//    public BoardScreen() {}
//
//    public void open() {}
//
//    public void create() {}
//
//    public void edit() {}
//}
//
//public class MenuItem {
//    private AbstractCommand command;
//
//    public MenuItem(AbstractCommand command) {
//        this.command = command;
//    }
//
//    public void click() {
//        command.execute();
//    }
//}
//
//public class Menu {
//    private ArrayList<MenuItem> menuItemList;
//
//    public void addMenuItem(MenuItem menuitem) {
//        menuItemList.add(menuitem);
//    }
//
//    public void clickMenuItem(int i) {
//        menuItemList.get(i).click();
//    }
//}
//
//public class Client {
//    public static void main(String args[]) {
//        Menu menu = new Menu();
//        BoardScreen bs = new BoardScreen();
//        AbstractCommand oc = new OpenCommand(bs);
//        AbstractCommand ec = new EditCommand(bs);
//        AbstractCommand cc = new CreateCommand(bs);
//
//        MenuItem item1 = new MenuItem(oc);
//        menu.addMenuItem(item1);
//        menu.clickMenuItem(0);
//
//        MenuItem item2 = new MenuItem(ec);
//        menu.addMenuItem(item2);
//        menu.clickMenuItem(1);
//
//        MenuItem item3 = new MenuItem(cc);
//        menu.addMenuItem(item3);
//        menu.clickMenuItem(2);
//    }
//}
//
//public abstract class Iterator {
//    public abstract String next();
//
//    public abstract String previous();
//}
//
//public class MyIterator extends Iterator{
//    private String[] goods;
//    int index1;
//    int index2;
//
//    public MyIterator(GoodSystem goodSystem) {
//        this.goods=goodSystem.getGoods();
//        this.index1=0;
//        this.index2=goodSystem.getGoods().length-1;
//    }
//    @Override
//    public String next() {
//        return goods[index1];
//    }
//
//    @Override
//    public String previous(){
//        return goods[index2];
//    }
//}
//
//public abstract class GoodSystem {
//    protected String[] goods;
//    public GoodSystem(String[] goods){
//        this.goods=goods;
//    }
//    public void setGoods(String[] goods){
//        this.goods=goods;
//    }
//    public String[] getGoods(){
//        return goods;
//    }
//
//    public abstract Iterator createIterator();
//
//}
//
//public class MyGoodSystem extends GoodSystem {
//
//    public MyGoodSystem(String[] goods){
//        super(goods);
//    }
//
//    @Override
//    public Iterator createIterator(){
//        return new MyIterator(this);
//    }
//}
//
//public abstract class AbstractChatRoom{
//    protected ArrayList<ChatMember> chatMembers;
//    public void register(ChatMember chatMember){
//        chatMembers.add(chatMember);
//    };
//    public abstract void sentMessage(String from,String to,String message);
//    public abstract void sentImage(String from,String to,String Image);
//}
//
//
//public class ChatRoom extends AbstractChatRoom{
//    @Override
//    public void register(ChatMember chatMember) {
//        super.register(chatMember);
//    }
//    @Override
//    public void sentMessage(String from,String to,String message){}
//    @Override
//    public void sentImage(String from,String to,String Image){}
//}
//
//public abstract class ChatMember{
//    protected AbstractChatRoom abstractChatRoom;
//    protected String name;
//
//    public ChatMember(String name,AbstractChatRoom abstractChatRoom){
//        this.abstractChatRoom=abstractChatRoom;
//        this.name=name;
//    }
//
//    public abstract void sentMessage(String to,String message);
//    public abstract void sentImage(String to,String image);
//
//}
//
//public class DiamondMember extends ChatMember{
//    public DiamondMember(String name,AbstractChatRoom abstractChatRoom){
//        super(name,abstractChatRoom);
//    }
//
//    @Override
//    public void sentMessage(String to,String message){
//        abstractChatRoom.sentMessage(name,to,message);
//    }
//    @Override
//    public void sentImage(String to,String image){
//        abstractChatRoom.sentImage(name,to,image);
//    }
//}
//
//public class CommonMember extends ChatMember{
//    public CommonMember(String name,AbstractChatRoom abstractChatRoom){
//        super(name,abstractChatRoom);
//    }
//
//    @Override
//    public void sentMessage(String to,String message){
//        abstractChatRoom.sentMessage(name,to,message);
//    }
//    @Override
//    public void sentImage(String to,String image){
//        //普通用户不能发送图片
//    }
//}
//public interface BasicEncryption {
//    public void encrypt();
//}
//
//public class MoveEncryption implements BasicEncryption{
//    @Override
//    public void encrypt() {}
//}
//
//public class EncryptionDecrator implements BasicEncryption{
//    private BasicEncryption basicEncryption;
//    public EncryptionDecrator(BasicEncryption basicEncryption) {
//        this.basicEncryption=basicEncryption;
//    }
//
//    public void encrypt() {
//        basicEncryption.encrypt();
//    }
//}
//public class ModEncryption extends EncryptionDecrator{
//    public BasicEncryption basicEncryption=null;
//    public ModEncryption(BasicEncryption basicEncryption) {
//        super(basicEncryption);
//    }
//    public void encrypt() {
//        basicEncryption.encrypt();
//    }
//}
//public class ReverseEncryption extends EncryptionDecrator{
//    public BasicEncryption basicEncryption=null;
//    public ReverseEncryption(BasicEncryption basicEncryption) {
//        super(basicEncryption);
//    }
//    public void encrypt() {
//        basicEncryption.encrypt();
//    }
//}
//
//public abstract class VedioType{
//    String name;
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//}
//
//public class MPEG extends VedioType{
//
//}
//public class RMVB extends VedioType{
//
//}
//public class WMV extends VedioType{
//
//}
//public class AVI extends VedioType{
//
//}
//
//public abstract class OS{
//    protected VedioType vedioType;
//
//    public void setVedioType(VedioType vedioType) {
//        this.vedioType = vedioType;
//    }
//
//    public abstract void playVedio();
//}
//
//public class Window extends OS{
//    @Override
//    public void playVedio(){
//        System.out.println("Window"+vedioType.getName());
//    }
//}
//
//public class linux extends OS{
//    @Override
//    public void playVedio(){
//        System.out.println("linux"+vedioType.getName());
//    }
//}
//
//public class Unix extends OS{
//    @Override
//    public void playVedio(){
//        System.out.println("Unix"+vedioType.getName());
//    }
//}
//
//public class Client{
//    public static void main(String args[]) {
//        Window window=new Window();
//        MPEG mpeg=new MPEG();
//        window.setVedioType(mpeg);
//        window.playVedio();
//    }
//}
//
